(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"ParveenJagajeevan_HCI472_animation_atlas_1", frames: [[1371,80,122,50],[1026,671,122,50],[1150,671,122,50],[1214,343,122,50],[1026,343,186,80],[1323,211,122,50],[1417,132,122,50],[1495,80,122,50],[1323,263,122,50],[1026,425,186,80],[1214,395,122,50],[1214,447,122,50],[1026,507,186,80],[1214,499,122,50],[1214,551,122,50],[1026,589,186,80],[1214,603,42,28],[0,770,1170,660],[1371,132,3,2],[1371,0,292,78],[1026,0,343,143],[1026,211,295,64],[1026,145,389,64],[1026,277,270,64],[0,0,1024,768]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_61 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_59 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_55 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_53 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_51 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_54 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_49 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_63 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["ParveenJagajeevan_HCI472_animation_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Start3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_43();
	this.instance.setTransform(16.05,8,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_60();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_57();
	this.instance_2.setTransform(16.05,8,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_59();
	this.instance_3.setTransform(16.05,8,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_61();
	this.instance_4.setTransform(16.05,8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_1},{t:this.instance_2}]},1).to({state:[{t:this.instance_1},{t:this.instance_3}]},1).to({state:[{t:this.instance_1},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,93,40);


(lib.Start2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_41();
	this.instance.setTransform(16.05,8,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_54();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_51();
	this.instance_2.setTransform(16.05,8,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_53();
	this.instance_3.setTransform(16.05,8,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_55();
	this.instance_4.setTransform(16.05,8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_1},{t:this.instance_2}]},1).to({state:[{t:this.instance_1},{t:this.instance_3}]},1).to({state:[{t:this.instance_1},{t:this.instance_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,93,40);


(lib.Start1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_39();
	this.instance.setTransform(16.05,8,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_46();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_45();
	this.instance_2.setTransform(16.05,8,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_47();
	this.instance_3.setTransform(16.05,8,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_48();
	this.instance_4.setTransform(0,0,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_49();
	this.instance_5.setTransform(16.05,8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_1},{t:this.instance_2}]},1).to({state:[{t:this.instance_4},{t:this.instance_3}]},1).to({state:[{t:this.instance_4},{t:this.instance_5}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,93,40);


(lib.Glow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF00").s().p("AgTAFIAAgJIAnAAIAAAJg");
	this.shape.setTransform(2,0.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AgTBOIAAibIAnAAIAACbg");
	this.shape_1.setTransform(2,-7.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF00").s().p("AgTCWIAAkrIAnAAIAAErg");
	this.shape_2.setTransform(2,-15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFF00").s().p("AgTBfIAAi9IAnAAIAAC9g");
	this.shape_3.setTransform(2,-9.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFF00").s().p("AgTAoIAAhPIAnAAIAABPg");
	this.shape_4.setTransform(2,-4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-30,4,31);


(lib.EmptyGraph = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(8,1,1).p("EA+0Ax+Mh8/AAAEg+zgx/MAAABj/");
	this.shape.setTransform(46.5,3.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-359.5,-320.9,812,648);


(lib.Curl5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// curl5_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D8D8D8").s().p("ApaJdIAAy5IS1S5g");
	this.shape.setTransform(60.3,-59.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-120,120.6,121);


(lib.Curl4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// curl4_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D8D8D8").s().p("AnlHqIgHvTIPZPTg");
	this.shape.setTransform(49.325,-49.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-98,98.7,97.9);


(lib.Curl3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// curl3_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D8D8D8").s().p("AmImoIMRNGIsKAKg");
	this.shape.setTransform(39.325,-42.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-85,78.7,84.9);


(lib.Curl2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// curl2_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D8D8D8").s().p("Ak1E2IAAprIJrJrg");
	this.shape.setTransform(31.025,-32);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-63,62.1,62);


(lib.Curl1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// curl1_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D8D8D8").s().p("AjsD/IAAn9IHZH9g");
	this.shape.setTransform(23.725,-25.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-51,47.5,51);


(lib.bulbbase = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bulb_svg
	this.instance = new lib.CachedBmp_37();
	this.instance.setTransform(18.5,73.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(18.5,73.5,21,14);


(lib.bulb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bulb_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D2D2D2").ss(1,0,0,4).p("AEehAQAAh2hUhUQhThTh3AAQh2AAhTBTQhUBUAAB2QAAAuAPArQAOAsAaAjIACACQAFAJANAPQAoAwAbAxQAoBHAAA0IDPAAQAAg0AohHQAbgwAogxQAKgKAIgOIACgCQAagjAOgsQAPgrAAgug");
	this.shape.setTransform(29.075,35.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhnFeQAAg1gohHQgbgwgogwQgNgQgFgHIgCgDQgagkgOgqQgPgrAAguQAAh3BUhUQBThTB2AAQB3AABTBTQBUBUAAB3QAAAugPArQgOAqgaAkIgCADQgIANgKAKQgoAwgbAwQgoBHAAA1g");
	this.shape_1.setTransform(29.075,35.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,59.2,72);


(lib.Bar4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("EgJ/AnEMAAAhOHIT/AAMAAABOHg");
	this.shape.setTransform(280.025,68.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(216.1,-181.5,127.9,500);


(lib.Bar3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("Ap/fQMAAAg+fIT/AAMAAAA+fg");
	this.shape.setTransform(97.025,119.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(33.1,-80.5,127.9,400);


(lib.Bar2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0099FF").s().p("Ap/V4MAAAgrvIT/AAMAAAArvg");
	this.shape.setTransform(-75.975,179.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-139.9,39.6,127.9,280);


(lib.Bar1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Arrowhead = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// noun_left_406213_2_svg
	this.instance = new lib.CachedBmp_36();
	this.instance.setTransform(-293.2,-165.3,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_35();
	this.instance_1.setTransform(-376.7,-132.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-376.7,-165.3,668.5,330);


(lib.Arrowbottom = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// noun_down_arrow_3699324_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CCFF").s().p("EgioAbGQGEhHFwiSQFviTFLjYQE4jHEAkLQD+kLC6lAQBZiZBCijIAlhOQAWguANghIAwioQA3iiAlisIAylbQAdirgEiyIADizIX2AAIgDALIiDG3Qg7DfhgDOIi8GjQgnBRhLB2Ih9DEIh6C/QgdAmgsA0IhKBXQiNC0ilCeQk+E2l9DjQl8DkmnCGQmNB/meAvQjrAbjrAAQi0AAizgQg");
	this.shape.setTransform(190.2375,-206.4316);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.5,-381.4,443.5,350);


// stage content:
(lib.ParveenJagajeevanHCI472animation = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {Start:0,"Keyframe-Anticipation":1,"Keyframe-Squash":37,"Keyframe-Ease":78};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,36,63,98];
	// timeline functions:
	this.frame_0 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button3.on('click', function(){
		/*
		Moves the playhead to the specified frame label in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay('Keyframe-Ease');
		});
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button2.on('click', function(){
		/*
		Moves the playhead to the specified frame label in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay('Keyframe-Squash');
		});
		var _this = this;
		/*
		Clicking on the specified symbol instance executes a function.
		*/
		_this.button1.on('click', function(){
		/*
		Moves the playhead to the specified frame label in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		*/
		_this.gotoAndPlay('Keyframe-Anticipation');
		});
	}
	this.frame_36 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}
	this.frame_63 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}
	this.frame_98 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(36).call(this.frame_36).wait(27).call(this.frame_63).wait(35).call(this.frame_98).wait(1));

	// Button3
	this.button3 = new lib.Start3();
	this.button3.name = "button3";
	this.button3.setTransform(900.9,525.8);
	new cjs.ButtonHelper(this.button3, 0, 1, 2, false, new lib.Start3(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button3).wait(99));

	// Button2
	this.button2 = new lib.Start2();
	this.button2.name = "button2";
	this.button2.setTransform(540.9,525.8);
	new cjs.ButtonHelper(this.button2, 0, 1, 2, false, new lib.Start2(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button2).wait(99));

	// Button1
	this.button1 = new lib.Start1();
	this.button1.name = "button1";
	this.button1.setTransform(155.8,525.8);
	new cjs.ButtonHelper(this.button1, 0, 1, 2, false, new lib.Start1(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button1).wait(99));

	// Text
	this.instance = new lib.CachedBmp_10();
	this.instance.setTransform(103.05,23.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_9();
	this.instance_1.setTransform(865.7,152.1,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_6();
	this.instance_2.setTransform(501.85,155.6,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_3();
	this.instance_3.setTransform(130.65,155.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(99));

	// Anticipation
	this.instance_4 = new lib.Curl1("synched",0);
	this.instance_4.setTransform(261.95,302.05,0.5759,0.5759);
	this.instance_4._off = true;

	this.instance_5 = new lib.Curl2("synched",0);
	this.instance_5.setTransform(260.15,303.6,1,1,0,0,0,31,-32);
	this.instance_5._off = true;

	this.instance_6 = new lib.Curl3("synched",0);
	this.instance_6.setTransform(253.05,313.6,1,1,0,0,0,39.3,-42.6);
	this.instance_6._off = true;

	this.instance_7 = new lib.Curl4("synched",0);
	this.instance_7.setTransform(241.75,320.6,1,1,0,0,0,49.3,-49.1);
	this.instance_7._off = true;

	this.instance_8 = new lib.Curl5("synched",0);
	this.instance_8.setTransform(231.05,331.6,1,1,0,0,0,60.3,-59.5);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(10).to({_off:false},0).to({regX:23.8,regY:-25.3,scaleX:0.3406,scaleY:0.3757,x:281.65,y:282.1},2,cjs.Ease.none).to({regX:23.7,regY:-25.5,scaleX:1,scaleY:1,x:268.3,y:300.8},2,cjs.Ease.none).to({_off:true,regX:31,regY:-32,x:260.15,y:303.6},2).wait(83));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(14).to({_off:false},2).to({_off:true,regX:39.3,regY:-42.6,x:253.05,y:313.6},2).wait(81));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(16).to({_off:false},2).to({_off:true,regX:49.3,regY:-49.1,x:241.75,y:320.6},2).wait(79));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(18).to({_off:false},2).to({_off:true,regX:60.3,regY:-59.5,x:231.05,y:331.6},2).wait(77));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(20).to({_off:false},2).to({scaleX:1.2827,scaleY:1.1479,x:215.9,y:344.55},2).to({regX:60.4,regY:-59.4,scaleX:1.5437,scaleY:1.4594,x:201.05,y:361.95},2).to({_off:true},2).wait(71));

	// Layer_21
	this.instance_9 = new lib.CachedBmp_63();
	this.instance_9.setTransform(127.4,358.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({_off:true},28).wait(71));

	// Foreground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(4,1,1).p("ADChyIAADlImDAAIAAjlg");
	this.shape.setTransform(267.525,288.925);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AthP9IAA/5IU+AAIGEAAIAADmImEAAIAAjmIAADmIGEAAIAAcTg");
	this.shape_1.setTransform(200.4,379.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#999999").s().p("AtgP9IAA/5IXmAAIgBAmIAPACIAAAwQAFABADAIIAEANQAEAGALAJQArAhAnApQAGAGgBAEQAFACAGAHQAFAHAEACQAFACAHAAIA8ABIAAcTg");
	this.shape_2.setTransform(200,379.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#999999").ss(4,1,1).p("AABBeIAAhYIARAAAABBeIhuAAIAAiqIAAgmIB/AAIAAB4IBcAAIAABtIhtAAg");
	this.shape_3.setTransform(275.575,288.575);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#999999").s().p("AtgP9IAA/5IXmAAIgBAmIABAAIAACrIBvAAIAAhYIARAAIgRAAIAABYIhvAAIAAirIAAgmICAAAIAAB5IBcAAIAABtIhtAAIAAgVIAAAVIBtAAIAAcTgANisWg");
	this.shape_4.setTransform(200,379.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("AthP9IAA/5IZnAAIAACZIBbAAIAAdggAKGvWIAAAAIAAgdg");
	this.shape_5.setTransform(200.05,378.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#999999").s().p("AthP9IAA/5IXSAAIAAAKQAAAOACAHQACAIAQARIC0C0QAaAaAOARIAAbig");
	this.shape_6.setTransform(200.05,378.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#999999").s().p("AthP9IAA/5IUfAAIAAAcIAIABIAAAtQAAALACAEQACAFALAJQAcAUAfAnIA0BDQAQASAhAjIArAsIABAGQAKAGAOAQIBEBSQAJALAIAEQAIADAMAAIA/AAIAAYzg");
	this.shape_7.setTransform(200.5,378.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#999999").s().p("AthP9IAA/5IT7AAIAABDIAsABIAAAGQAAALACAEQACAFALAJQAcAUAfAnIA0BDQAQASAhAjIArAsIABAGQAKAGAOAQIBEBSIAHAIIAAAeIAPAAIAAAKIAFAAIAAAUIBJABIAAYAg");
	this.shape_8.setTransform(200.5,378.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#999999").s().p("AthP9IAA/5ISYAAIAAAPIAeADQgGAOASAYIBUBnQAcAjANAMIAaAXIAcAWQAUAQAxAuQBAA/AaAeIA1A+QAVAWAkAgQAXAUAPAGQALAFAPABIAAXPg");
	this.shape_9.setTransform(200.5,378.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#999999").s().p("AthP9IAA/5IRqAAIAABMIAOABIgBAnIAzABIAAAbIBlBBIANAJIgBArQAmAKAoAoIAhAiQATAVANAMQAKAIApAfQAsAiAyAzQAbAbA8BCQAbAeAQAMIAFAEIAAV4g");
	this.shape_10.setTransform(200.5,378.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#999999").s().p("AthP9IAA/5IQMAAIgBAiIATADQAAATAcAZIA9A6QAZAYALASQARAagBAYIgCARQgBAJACAHQACANAUASQDPC7DEDHIAWAYQALAPADAOIBLABIAAUag");
	this.shape_11.setTransform(200.5,378.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#999999").s().p("AthP9IAA/5IOiAAQABAKADAFQACAFAHAGIAtApQAOAMAGADQBMBbA8BTQAIAKAGADQAEACAJAAIAZAAQAGALAOANIA5A0IAAA2QANACAPAKQAIAFAQAOQDLC1CiDTIAoAAIAATBg");
	this.shape_12.setTransform(200.5,378.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#999999").s().p("AthP9IAA/5INEAAIgBBiIBgAFQgNAlAXApQAOAbAkAkQA/A+BXBNICbCEQB/BsBFBGQBlBoA9BmIBMAAIAAR2g");
	this.shape_13.setTransform(200.5,378.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#999999").s().p("AthP9IAA/5ILbAAIAAAGIAbAjQAMAOAHAOIAOAbQADAGAFAEIAMAMQAHAHACABIAKACIAQABQAPATALAUQgCAgAIAQQAFAOASATIBGBKQAqAuAeAZIApAfQAcAVAMALQAbAWAqAqIC0C4QBEBFAkAhQAlAhBBAzIBUBEQAWASAOAGQANAFASACIAAQbg");
	this.shape_14.setTransform(200.5,378.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#999999").s().p("AthP9IAA/5IJyAAIgBALQgDAmALATQAGALAZAUIB2BXQAhAZAQATQAYAcAAAdQARgCAXAcQA6BHBLA4IgBBGQAzAYA8AxQAiAcBDA7IBIA8QAwAqBPBYQAmAqARAWQAeAkAVAjQAMAVALAEQAHADAPAAIAoAAQAZA7ANBBIA/ABIAAN9g");
	this.shape_15.setTransform(200.5,378.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#999999").s().p("AthP9IAA/5IG5AAIAUAPQASAPAeAfQBEBGCFCNQB3B7BbBOQAsAlAPAPIAVAUIAAAiQAZADAaAPQASAKAdAVIANAJIgUgBIgBBtQAWgCAiAWQBUA5BGBJIAvAzQAcAdAYARQATAOAqAXQArAbA8A5QBMBGAXATQAiAaAYAHIAKACIAAMkg");
	this.shape_16.setTransform(200.5,378.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#999999").s().p("AthP9IAA/5IEKAAIgBBPQAoARApAOIgBBHQBRAfBNAlQgCAeAHARQAFAOASASQAcAcAqAhIBKA3QBIA2B8B0QCCB4BCAzIBKA4QAqAiAbAcIAXAZIAAAIIAGAAIgBBDQAAAOADAFQAFAMAWAHQAbAHAHAGIAABHQAPAGAhAHQAWAGAhAPIA1AaQAbAMA4ATQAyATAbAXIAaAZIAXAXIAgABIAAAVIAfAAIAALJg");
	this.shape_17.setTransform(200.5,378.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#999999").s().p("AthP9IAA/5IBmAAIAAAmQAnAyBXBDQBjBLAhAkIAnAuQAYAcAQAQQAPAPAYAUIAoAhQAoAiAuAzIBOBdQAVAaARAIQATAKAjgCIAIgBQBBBAB7BiIAAAPIgLABIgBBsQATAAAWAMQANAGAZARIDkChQAlAaATAQQAfAYAUAXQALAMAUAcQAUAbAMANQAmApBWAvQBiA1AhAdIAdAbIALAKIAAIcg");
	this.shape_18.setTransform(200.5,378.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#999999").s().p("AthPGIAA+LIBOAkQgHAoAMApQAPA1AnAjIAWARQALAKAGAJQAJAOAFAcQAHAhAEALQAMAdAjAUQAWANAlALQA0AbA2AVIjeABIAABtQCVAWCpALIACA7QBYAFBWAWIAAAdIBMAQIiDAAQgEAtACAXQACAmAOAbIhyACIgBBsIDKADQgNA3AFA5QBYAJBSAZQAHACAFAFQAFAFgEAFIhiACIgBBsICuAEIgBBSQBBAEBAAQIgBBRQAmABAvANQAZAHA4AVICYA6QBfAlA7APQBTAWBAgIIABh6IACAAIAAHLg");
	this.shape_19.setTransform(200.5,383.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_2}]},9).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[]},2).to({state:[]},69).wait(2));

	// Layer_20
	this.instance_10 = new lib.Bitmap1();
	this.instance_10.setTransform(126,328,0.145,0.145);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(10).to({_off:false},0).to({_off:true},27).wait(62));

	// Background
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#0A6FDB").s().p("AtgP9IAA/5IbBAAIAAf5g");
	this.shape_20.setTransform(200.1,378.975);
	this.shape_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(10).to({_off:false},0).to({_off:true},27).wait(62));

	// Layer_9
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#999999").ss(4,1,1).p("At4wQIbxAAMAAAAghI7xAAg");
	this.shape_21.setTransform(200.1,378.925);

	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(99));

	// Glow_8_copy
	this.instance_11 = new lib.Glow("synched",0,false);
	this.instance_11.setTransform(493.75,383.15,1,1,0,-90,90,2,-49.5);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(60).to({_off:false},0).to({_off:true},3).wait(36));

	// Glow_7_copy_copy
	this.instance_12 = new lib.Glow("synched",0,false);
	this.instance_12.setTransform(494.4,344.35,1,1,0,-75,105,2,-49.5);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(58).to({_off:false},0).to({_off:true},5).wait(36));

	// Glow_6
	this.instance_13 = new lib.Glow("synched",0,false);
	this.instance_13.setTransform(532.95,296.3,1,1,0,-24.9997,155.0003,2,-49.5);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(56).to({_off:false},0).to({_off:true},7).wait(36));

	// Glow_5
	this.instance_14 = new lib.Glow("synched",0,false);
	this.instance_14.setTransform(563.55,282.75,1,1,0,-10.9987,169.0013,2,-49.4);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(54).to({_off:false},0).to({_off:true},9).wait(36));

	// Glow_4
	this.instance_15 = new lib.Glow("synched",0,false);
	this.instance_15.setTransform(601.7,281.05,1,1,10.9987,0,0,2,-49.4);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(52).to({_off:false},0).to({_off:true},11).wait(36));

	// Glow_3
	this.instance_16 = new lib.Glow("synched",0,false);
	this.instance_16.setTransform(632.4,293.25,1,1,24.9997,0,0,2,-49.5);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(50).to({_off:false},0).to({_off:true},13).wait(36));

	// Glow_2
	this.instance_17 = new lib.Glow("synched",0,false);
	this.instance_17.setTransform(671.1,341.35,1,1,73.0006,0,0,2.1,-49.5);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(48).to({_off:false},0).to({_off:true},15).wait(36));

	// Glow_1
	this.instance_18 = new lib.Glow("synched",0,false);
	this.instance_18.setTransform(673.9,378.4,1,1,90,0,0,2,-49.5);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(46).to({_off:false},0).to({_off:true},17).wait(36));

	// Bulb
	this.instance_19 = new lib.bulb("synched",0);
	this.instance_19.setTransform(584.15,386.05,1,1,0,0,0,29.1,43.8);
	var instance_19Filter_1 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_19.filters = [instance_19Filter_1];
	this.instance_19.cache(-2,-2,63,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(38).to({x:584.65},0).to({startPosition:0},7).wait(18).to({startPosition:0},0).to({startPosition:0},4).wait(32));
	this.timeline.addTween(cjs.Tween.get(instance_19Filter_1).wait(38).to(new cjs.ColorFilter(0,0,0,1,228,228,0,0), 7).wait(18).to(new cjs.ColorFilter(1,1,1,1,0,0,0,0), 4).wait(32));

	// Base
	this.instance_20 = new lib.bulbbase("synched",0);
	this.instance_20.setTransform(584.55,426.1,1,1,0,0,0,29,80.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(99));

	// Ease
	this.instance_21 = new lib.Arrowhead("synched",0);
	this.instance_21.setTransform(845.65,375.4,0.0573,0.075,90,0,0,-10.5,124);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(79).to({_off:false},0).wait(1).to({regX:-42.5,regY:-0.3,scaleX:0.0633,scaleY:0.0805,rotation:86.8244,x:860.45,y:371.75},0).wait(1).to({scaleX:0.0658,scaleY:0.0827,rotation:85.5031,x:862.75,y:371.05},0).wait(1).to({scaleX:0.0682,scaleY:0.0848,rotation:84.2879,x:864.85,y:370.3},0).wait(1).to({scaleX:0.0706,scaleY:0.087,rotation:82.994,x:867.05,y:369.55},0).wait(1).to({scaleX:0.0734,scaleY:0.0895,rotation:81.5354,x:869.55,y:368.7},0).wait(1).to({scaleX:0.0766,scaleY:0.0924,rotation:79.8503,x:872.4,y:367.7},0).wait(1).to({scaleX:0.0804,scaleY:0.0958,rotation:77.881,x:875.7,y:366.5},0).wait(1).to({regX:-10.8,regY:123.9,scaleX:0.0848,scaleY:0.0998,rotation:75.5642,x:868.2,y:370.8},0).wait(1).to({regX:-42.5,regY:-0.3,scaleX:0.0901,scaleY:0.1045,rotation:72.8219,x:884,y:363.05},0).wait(1).to({scaleX:0.0963,scaleY:0.1101,rotation:69.5525,x:889.3,y:360.55},0).wait(1).to({scaleX:0.1038,scaleY:0.1168,rotation:65.6121,x:895.6,y:357.55},0).wait(1).to({regX:-10.3,regY:124,scaleX:0.1131,scaleY:0.1251,rotation:60.7831,x:891.25,y:364.5},0).wait(1).to({regX:-42.5,regY:-0.3,scaleX:0.1247,scaleY:0.1355,rotation:54.6992,x:912.15,y:342.55},0).wait(1).to({scaleX:0.1401,scaleY:0.1493,rotation:46.6534,x:923.65,y:327.6},0).wait(1).to({scaleX:0.1627,scaleY:0.1695,rotation:34.8197,x:939.4,y:305.95},0).wait(1).to({regX:-10.2,regY:123.9,scaleX:0.2292,scaleY:0.2292,rotation:0,x:986,y:274.95},0).wait(4));

	// Layer_12 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_79 = new cjs.Graphics().p("AhYDzIAAnlICxAAIAAHlg");
	var mask_graphics_85 = new cjs.Graphics().p("AiADzIAAnlIEBAAIAAHlg");
	var mask_graphics_87 = new cjs.Graphics().p("AisDzIAAnlIFZAAIAAHlg");
	var mask_graphics_90 = new cjs.Graphics().p("AjeDzIAAnlIG9AAIAAHlg");
	var mask_graphics_92 = new cjs.Graphics().p("AkqDzIAAnlIJVAAIAAHlg");
	var mask_graphics_93 = new cjs.Graphics().p("Al2DzIAAnlILtAAIAAHlg");
	var mask_graphics_94 = new cjs.Graphics().p("Ao+GJIAAsRIR9AAIAAMRg");
	var mask_graphics_95 = new cjs.Graphics().p("AuILVIAA2pIcRAAIAAWpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(79).to({graphics:mask_graphics_79,x:851.4747,y:378.7997}).wait(6).to({graphics:mask_graphics_85,x:858.4866,y:378.7997}).wait(2).to({graphics:mask_graphics_87,x:862.9987,y:378.7997}).wait(3).to({graphics:mask_graphics_90,x:869.013,y:378.7997}).wait(2).to({graphics:mask_graphics_92,x:878.0341,y:378.7997}).wait(1).to({graphics:mask_graphics_93,x:886.5558,y:378.7997}).wait(1).to({graphics:mask_graphics_94,x:900.7618,y:366.0997}).wait(1).to({graphics:mask_graphics_95,x:935.3497,y:355.9248}).wait(4));

	// Arrow
	this.instance_22 = new lib.Arrowbottom("synched",0);
	this.instance_22.setTransform(946.35,302.95,0.4023,0.288,0,0,0,231.3,-293.4);
	this.instance_22._off = true;

	var maskedShapeInstanceList = [this.instance_22];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(79).to({_off:false},0).wait(20));

	// Layer_16
	this.instance_23 = new lib.Bar4("synched",0);
	this.instance_23.setTransform(1010.35,372.55,0.2102,0.284,0,0,0,280.2,69.2);
	this.instance_23._off = true;
	var instance_23Filter_2 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_23.filters = [instance_23Filter_2];
	this.instance_23.cache(214,-183,132,504);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(95).to({_off:false},0).wait(4));
	this.timeline.addTween(cjs.Tween.get(instance_23Filter_2).wait(95).to(new cjs.ColorFilter(0.16,0.16,0.16,1,213.36,214.2,0,0), 0).wait(4));

	// Layer_15
	this.instance_24 = new lib.Bar3("synched",0);
	this.instance_24.setTransform(965.5,396.95,0.2102,0.2299,0,0,0,97.2,120);
	this.instance_24._off = true;
	var instance_24Filter_3 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_24.filters = [instance_24Filter_3];
	this.instance_24.cache(31,-82,132,404);

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(94).to({_off:false},0).wait(5));
	this.timeline.addTween(cjs.Tween.get(instance_24Filter_3).wait(94).to(new cjs.ColorFilter(0.24,0.24,0.24,1,193.04,193.8,0,0), 0).wait(5));

	// Layer_14
	this.instance_25 = new lib.Bar2("synched",0);
	this.instance_25.setTransform(920.5,407.7,0.2106,0.2583,0,0,0,-75.8,180.2);
	this.instance_25._off = true;
	var instance_25Filter_4 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_25.filters = [instance_25Filter_4];
	this.instance_25.cache(-142,38,132,284);

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(93).to({_off:false},0).wait(6));
	this.timeline.addTween(cjs.Tween.get(instance_25Filter_4).wait(93).to(new cjs.ColorFilter(0.33,0.33,0.33,1,170.18,170.85,0,0), 0).wait(6));

	// Layer_13
	this.instance_26 = new lib.Bar2("synched",0);
	this.instance_26.setTransform(873.4,413.3,0.2106,0.2157,0,0,0,-75.8,180.3);
	this.instance_26._off = true;
	var instance_26Filter_5 = new cjs.ColorFilter(1,1,1,1,0,0,0,0);
	this.instance_26.filters = [instance_26Filter_5];
	this.instance_26.cache(-142,38,132,284);

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(91).to({_off:false},0).wait(8));
	this.timeline.addTween(cjs.Tween.get(instance_26Filter_5).wait(91).to(new cjs.ColorFilter(0.4,0.4,0.4,1,152.4,153,0,0), 0).wait(8));

	// Graph
	this.instance_27 = new lib.EmptyGraph("synched",0);
	this.instance_27.setTransform(942.45,364.15,0.25,0.25,0,0,0,46.6,3.2);

	this.instance_28 = new lib.Bar1("synched",0);
	this.instance_28.setTransform(956,354.35,0.2813,0.2813,0,0,0,46.6,3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_28},{t:this.instance_27}]}).wait(99));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.instance_19, startFrame:38, endFrame:38, x:-2, y:-2, w:63, h:76});
	this.filterCacheList.push({instance: this.instance_19, startFrame:39, endFrame:45, x:-2, y:-2, w:63, h:76});
	this.filterCacheList.push({instance: this.instance_19, startFrame:64, endFrame:67, x:-2, y:-2, w:63, h:76});
	this.filterCacheList.push({instance: this.instance_23, startFrame:95, endFrame:95, x:214, y:-183, w:132, h:504});
	this.filterCacheList.push({instance: this.instance_23, startFrame:0, endFrame:0, x:214, y:-183, w:132, h:504});
	this.filterCacheList.push({instance: this.instance_24, startFrame:94, endFrame:94, x:31, y:-82, w:132, h:404});
	this.filterCacheList.push({instance: this.instance_24, startFrame:0, endFrame:0, x:31, y:-82, w:132, h:404});
	this.filterCacheList.push({instance: this.instance_25, startFrame:93, endFrame:93, x:-142, y:38, w:132, h:284});
	this.filterCacheList.push({instance: this.instance_25, startFrame:0, endFrame:0, x:-142, y:38, w:132, h:284});
	this.filterCacheList.push({instance: this.instance_26, startFrame:91, endFrame:91, x:-142, y:38, w:132, h:284});
	this.filterCacheList.push({instance: this.instance_26, startFrame:0, endFrame:0, x:-142, y:38, w:132, h:284});
	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(703.1,323.5,352.1,242.29999999999995);
// library properties:
lib.properties = {
	id: '672C6392198E4B9C8EDE2742CC27334C',
	width: 1200,
	height: 600,
	fps: 24,
	color: "#333333",
	opacity: 1.00,
	manifest: [
		{src:"images/ParveenJagajeevan_HCI472_animation_atlas_1.png", id:"ParveenJagajeevan_HCI472_animation_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['672C6392198E4B9C8EDE2742CC27334C'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;